# Here are the list of mini-projects offered as homework along with notebooks containing solutions presented by students.

## Mechanical System

## Heat of formation

## Beer-Lambert's law

## Mass pectroscopy

## Kepler's law

## Stiff ODE application to reaction

## Hydrogen atom

## Hydrogen molecule cation

## A problem in electrostatics
